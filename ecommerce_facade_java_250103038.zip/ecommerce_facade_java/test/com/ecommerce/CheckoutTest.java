package com.ecommerce;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CheckoutTest {
    public static void main(String[] args) throws Exception {
        CheckoutFacade checkout = new CheckoutFacade();
        verifyOrder(checkout, "Missing-SKU", 1_200, false, "[CheckoutFacade] Item out of stock.");
        verifyOrder(checkout, "Laptop-X1", Double.NaN, false, "[CheckoutFacade] Invalid order details.");
        verifyOrder(checkout, "Laptop-X1", 6_000, false,
                "[InventoryService]", "[CheckoutFacade] Payment declined.");
        verifyOrder(checkout, "Laptop-X1", 1_200, true,
                "[InventoryService]", "[PaymentGateway]", "[ShippingService]", "[NotificationService]");
        verifyOrder(checkout, "Laptop-X1", 1_200, false, "[CheckoutFacade] Item out of stock.");

        InventoryService inventory = new InventoryService();
        ExecutorService executor = Executors.newFixedThreadPool(2);
        CountDownLatch start = new CountDownLatch(1);
        try {
            Future<Boolean> first = executor.submit(() -> {
                start.await();
                return inventory.reserve("Laptop-X1");
            });
            Future<Boolean> second = executor.submit(() -> {
                start.await();
                return inventory.reserve("Laptop-X1");
            });
            start.countDown();
            require(first.get() ^ second.get(), "Only one reservation may succeed");
        } finally {
            executor.shutdownNow();
        }
        System.out.println("All checkout checks passed.");
    }

    private static void verifyOrder(CheckoutFacade checkout, String product, double amount,
                                    boolean expected, String... expectedSteps) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        PrintStream original = System.out;
        boolean success;
        try (PrintStream capture = new PrintStream(output, true, StandardCharsets.UTF_8)) {
            System.setOut(capture);
            success = checkout.placeOrder(product, "user_404", "123 Main St", amount);
        } finally {
            System.setOut(original);
        }
        require(success == expected, "Unexpected checkout result");
        String log = output.toString(StandardCharsets.UTF_8);
        int position = 0;
        for (String step : expectedSteps) {
            int index = log.indexOf(step, position);
            require(index >= 0, "Missing or out-of-order step " + step + "\n" + log);
            position = index + step.length();
        }
        if (!expected) {
            require(!log.contains("[PaymentGateway]") && !log.contains("[ShippingService]")
                    && !log.contains("[NotificationService]"), "Failed order continued processing");
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
