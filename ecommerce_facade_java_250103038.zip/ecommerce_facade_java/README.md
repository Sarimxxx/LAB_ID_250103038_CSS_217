# CSS 217 · E-commerce Checkout Facade

Student: Miras Baltabaev

Student ID: 250103038

`OrderController` uses one public checkout operation, `CheckoutFacade.placeOrder`. The
facade validates the request, reserves an item, charges the customer, schedules
delivery, and sends a receipt. If payment is declined, it releases the reservation
before returning. Inventory checks and decrements run under the same lock.

## Build and run

Run these commands from this directory with JDK 11 or later. No external
dependencies are needed.

```sh
javac -d out -sourcepath src src/com/ecommerce/OrderController.java
java -cp out com.ecommerce.OrderController
javac -cp out -d out test/com/ecommerce/CheckoutTest.java
java -cp out com.ecommerce.CheckoutTest
```

The demo starts with one Laptop-X1 and a simulated payment limit of $5,000 per
transaction. The demo declines a $6,000 payment, successfully retries at $1,200,
then reports that stock is exhausted. Shipping and receipt delivery are simulated
with console messages. Each new facade starts with fresh in-memory inventory.

## Design decisions

The facade reuses concrete subsystem instances across calls. The project has one
implementation of each service, so the facade calls those services directly.
The public checkout method uses primitive `double` and `boolean`, keeping boxing
out of that API. The demo has fixed console messages and no bulk data processing
loop. There are no performance measurements. In a real checkout, use a monetary
type or integer minor units and persist inventory and order state across requests.
