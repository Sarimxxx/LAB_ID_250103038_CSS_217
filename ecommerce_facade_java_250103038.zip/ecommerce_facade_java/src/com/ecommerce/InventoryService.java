package com.ecommerce;

import java.util.HashMap;
import java.util.Map;

/** In-memory inventory for the checkout demo. */
public class InventoryService {
    private final Map<String, Integer> stock = new HashMap<>(Map.of("Laptop-X1", 1));

    public synchronized boolean checkStock(String productId) {
        return stock.getOrDefault(productId, 0) > 0;
    }

    public synchronized boolean reserve(String productId) {
        if (!checkStock(productId)) {
            return false;
        }

        stock.put(productId, stock.get(productId) - 1);
        System.out.println("[InventoryService] Stock reserved for " + productId);
        return true;
    }

    synchronized void release(String productId) {
        stock.put(productId, stock.get(productId) + 1);
    }
}
