package com.ecommerce;

/** Simulates a payment processor with a fixed limit per transaction. */
public class PaymentGateway {
    private static final double DEMO_PAYMENT_LIMIT = 5_000.00;

    public boolean charge(String customerId, double amount) {
        if (!Double.isFinite(amount) || amount <= 0 || amount > DEMO_PAYMENT_LIMIT) {
            return false;
        }

        System.out.println("[PaymentGateway] Payment of $" + amount + " captured for " + customerId);
        return true;
    }
}
