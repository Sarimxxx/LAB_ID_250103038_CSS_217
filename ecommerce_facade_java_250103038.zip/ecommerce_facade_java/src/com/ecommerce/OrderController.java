package com.ecommerce;

/** Runs three checkout scenarios through the same facade instance. */
public class OrderController {
    public static void main(String[] args) {
        CheckoutFacade checkout = new CheckoutFacade();
        showCheckout(checkout, "Payment declined", 6_000.00);
        showCheckout(checkout, "Successful retry", 1_200.00);
        showCheckout(checkout, "Out of stock", 1_200.00);
    }

    private static void showCheckout(CheckoutFacade checkout, String scenario, double amount) {
        System.out.println("\n--- " + scenario + " ---");
        boolean success = checkout.placeOrder("Laptop-X1", "user_404", "123 Main St", amount);
        System.out.println("Order completed = " + success);
    }
}
