package com.ecommerce;

/** Coordinates the four checkout services behind one operation. */
public class CheckoutFacade {
    private final InventoryService inventory = new InventoryService();
    private final PaymentGateway payment = new PaymentGateway();
    private final ShippingService shipping = new ShippingService();
    private final NotificationService notification = new NotificationService();

    public boolean placeOrder(String productId, String customerId, String address, double amount) {
        if (isBlank(productId) || isBlank(customerId) || isBlank(address)
                || !Double.isFinite(amount) || amount <= 0) {
            System.out.println("[CheckoutFacade] Invalid order details.");
            return false;
        }

        if (!inventory.reserve(productId)) {
            System.out.println("[CheckoutFacade] Item out of stock.");
            return false;
        }

        if (!payment.charge(customerId, amount)) {
            inventory.release(productId);
            System.out.println("[CheckoutFacade] Payment declined. Reservation released.");
            return false;
        }

        shipping.scheduleDelivery(productId, address);
        notification.sendReceipt(customerId, amount);
        return true;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
